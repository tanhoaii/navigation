import React from 'react'
import { View, Text, Image } from 'react-native'

function Nam() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#A8EDF0' }}>
      <Text style={{ fontSize: 40, color: 'maroon' }}>Đoàn Trung Nam</Text>
      <Text style={{ fontSize: 40, color: 'maroon' }}>MSSV: B2016913</Text>
    </View>
  );
}
export default Nam;