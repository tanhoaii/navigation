import React from 'react'
import { View, Text, Image } from 'react-native'

function Thinh() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#A8EDF0' }}>
      <Text style={{ fontSize: 40, color: 'yellow' }}>Trần Quốc Thịnh</Text>
      <Text style={{ fontSize: 40, color: 'yellow' }}>MSSV: B2016867</Text>
    </View>
  );
}
export default Thinh;