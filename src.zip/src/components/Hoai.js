import React from 'react'
import { View, Text, Image } from 'react-native'

function Hoai() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#A8EDF0' }}>
      <Text style={{ fontSize: 40, color: 'blue' }}>Phạm Tấn Hoài</Text>
      <Text style={{ fontSize: 40, color: 'blue' }}>MSSV: B2016899</Text>
    </View>
  );
}
export default Hoai;