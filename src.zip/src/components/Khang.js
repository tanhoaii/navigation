import React from 'react'
import { View, Text, Image } from 'react-native'

function Khang() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#A8EDF0' }}>
      <Text style={{ fontSize: 40, color: 'gray' }}>Hoàng Khang</Text>
      <Text style={{ fontSize: 40, color: 'gray' }}>MSSV: B2016837</Text>
    </View>
  );
}
export default Khang;