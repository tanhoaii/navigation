import React from 'react'
import { View, Text, Image } from 'react-native'

function Kiet() {
    return (
      <View style={{flex: 1,alignItems: 'center', justifyContent: 'center', backgroundColor: '#A8EDF0'}}>
        <Text style={{fontSize: 40, color: 'green'}}>Cao Minh Trí Kiệt</Text>
        <Text style={{fontSize: 40, color: 'green'}}>MSSV: B2007816</Text>
      </View>
    );
  }
export default Kiet;