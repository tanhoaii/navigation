import React from 'react'
import { View, Text, Image } from 'react-native'

function Dat() {
    return (
      <View style={{flex: 1,alignItems: 'center', justifyContent: 'center', backgroundColor: '#A8EDF0'}}>
        <Text style={{fontSize: 40, color: 'orange'}}>Huỳnh Tuấn Đạt</Text>
        <Text style={{fontSize: 40, color: 'orange'}}>MSSV: B2016890</Text>
      </View>
    );
  }
export default Dat;